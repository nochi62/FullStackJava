$(document).ready(function() {
    $("#fecha_1").datepicker();
    $("#fecha_2").datepicker();

    $("#validate").click(function() {
        var date_1 = $("#fecha_1").val();
        var date_2 = $("#fecha_2").val();
        var lastday = new Date(2020, 12, 31);

        if (date_1 > date_2) {
            $("#diff").text("Fecha 1 es mayor que Fecha 2.");
            $("#endyear").text("Hay " + (Date.parse(lastday) - Date.parse(date_1)) / 86400000 + " dias para fin de año.");
        } else if (date_1 == date_2) {
            $("#diff").text("Ambas fechas son iguales.");
            $("#endyear").text("Hay " + (Date.parse(lastday) - Date.parse(date_1)) / 86400000 + " dias para fin de año.");
        } else {
            $("#diff").text("Fecha 2 es mayor que Fecha 1.");
            $("#endyear").text("Hay " + (Date.parse(lastday) - Date.parse(date_2)) / 86400000 + " dias para fin de año.");
        }

        var vdiff = Math.abs(Date.parse(date_1) - Date.parse(date_2));
        $("#ndays").text("Hay " + vdiff / 86400000 + " dias entre ambas fechas.");
    })
});