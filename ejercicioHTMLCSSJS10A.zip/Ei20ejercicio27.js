function procesamiento() {
    error = "-";
    valor = "-";
    valornum = 0;
    var mensaje = " ";

    valor = document.getElementById("nombre").value;
    if (valor == null || valor.length == 0 || valor.length > 30 || /^\s+$/.test(valor)) {
        error = error + "Error en campo Nombre + ";
    }

    valor = document.getElementById("apellidos").value;
    if (valor == null || valor.length == 0 || valor.length > 30 || /^\s+$/.test(valor)) {
        error = error + "Error en campo Apellidos + ";
    }

    valor = document.getElementById("fechanac").value;
    if (valor == null) {
        error = error + "Error en campo Fecha + ";
    }

    //valornum = document.parseint(getElementById("telefono").value);
    //if (valornum == null || valornum.length == 0 || valor.length < 7 || valor.length > 12) {
    //    error = error + "Error en campo Telefono + ";
    //}


    valor = document.getElementById("direccion").value;
    if (valor == null || valor.length == 0 || valor.length > 100 || /^\s+$/.test(valor)) {
        error = error + "Error en campo Dirección + ";
    }

    valor = document.getElementById("ciudad").value;
    if (valor == null || valor.length == 0 || valor.length > 30 || /^\s+$/.test(valor)) {
        error = error + "Error en campo Ciudad + ";
    }

    if (error != "-") {
        alert(error);
    } else {
        fechahoy = new Date()
        fechanacim = new Date(document.getElementById("fechanac").value) // remember this is equivalent to 06 01 2010

        var diferencia = Math.floor(fechahoy.getTime() - fechanacim.getTime());
        var dia = 1000 * 60 * 60 * 24;

        var dias = Math.floor(diferencia / dia);
        var meses = Math.floor(dias / 31);
        var anos = Math.floor(meses / 12);

        mensaje += " Son "
        mensaje += anos + " anos "
        mensaje += meses + " meses "
        mensaje += dias + " dias "

        alert(mensaje + document.getElementById("nombre").value + " " + document.getElementById("apellidos").value)
    }
}