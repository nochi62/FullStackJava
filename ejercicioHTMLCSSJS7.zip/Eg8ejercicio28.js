document.addEventListener('click', printMousePosmove, true);
document.addEventListener('mousemove', printMousePos, true);
var list_coord = [];

function printMousePos(e) {
    var sum = 0;
    var curX = e.pageX;
    var curY = e.pageY;
    document.getElementById("text_coord").innerHTML = `X: ${curX} Y: ${curY}`;

}

function printMousePosmove(e) {
    var curX = e.pageX;
    var curY = e.pageY;
    var coord = "X: " + curX + " Y: " + curY;
    // coord.push(`${curX} ${curY}`)
    // coord.push(curX);
    // coord.push(curY);
    console.log(coord);
    arrayCoord(coord);
}

function arrayCoord(array) {

    var para = document.createElement("P");
    para.innerHTML = array
        // console.log(list_coord);
    document.getElementById("list_coord").appendChild(para);
}