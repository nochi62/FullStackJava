function cambiar_color1() {
    celda = document.getElementById("celda1")
    celda.style.backgroundColor = "#dddddd"

}

function cambiar_color2() {
    celda = document.getElementById("celda2")
    celda.style.backgroundColor = "#dddddd"

}

function cambiar_color3() {
    celda = document.getElementById("celda3")
    celda.style.backgroundColor = "#dddddd"

}

function cambiar_color4() {
    celda = document.getElementById("celda4")
    celda.style.backgroundColor = "#dddddd"

}

function cambiar_color5() {
    celda = document.getElementById("celda5")
    celda.style.backgroundColor = "#dddddd"

}

function cambiar_color6() {
    celda = document.getElementById("celda6")
    celda.style.backgroundColor = "#dddddd"

}

function cambiar_color7() {
    celda = document.getElementById("celda7")
    celda.style.backgroundColor = "#dddddd"

}

function cambiar_color8() {
    celda = document.getElementById("celda8")
    celda.style.backgroundColor = "#dddddd"

}

function cambiar_color9() {
    celda = document.getElementById("celda9")
    celda.style.backgroundColor = "#dddddd"

}

function cambiar_color10() {
    celda = document.getElementById("celda10")
    celda.style.backgroundColor = "#dddddd"

}

function cambiar_color11() {
    celda = document.getElementById("celda11")
    celda.style.backgroundColor = "#dddddd"

}

function cambiar_color12() {
    celda = document.getElementById("celda12")
    celda.style.backgroundColor = "#dddddd"

}

function cambiar_color13() {
    celda = document.getElementById("celda13")
    celda.style.backgroundColor = "#dddddd"

}

function cambiar_color14() {
    celda = document.getElementById("celda14")
    celda.style.backgroundColor = "#dddddd"

}

function cambiar_color15() {
    celda = document.getElementById("celda15")
    celda.style.backgroundColor = "#dddddd"

}

function cambiar_color16() {
    celda = document.getElementById("celda16")
    celda.style.backgroundColor = "#dddddd"

}

function cambiar_color17() {
    celda = document.getElementById("celda17")
    celda.style.backgroundColor = "#dddddd"

}

function cambiar_color18() {
    celda = document.getElementById("celda18")
    celda.style.backgroundColor = "#dddddd"

}

function cambiar_color19() {
    celda = document.getElementById("celda19")
    celda.style.backgroundColor = "#dddddd"

}

function cambiar_color20() {
    celda = document.getElementById("celda20")
    celda.style.backgroundColor = "#dddddd"

}

function cambiar_color21() {
    celda = document.getElementById("celda21")
    celda.style.backgroundColor = "#dddddd"

}

function cambiar_color22() {
    celda = document.getElementById("celda22")
    celda.style.backgroundColor = "#dddddd"

}

function cambiar_color23() {
    celda = document.getElementById("celda23")
    celda.style.backgroundColor = "#dddddd"

}

function cambiar_color24() {
    celda = document.getElementById("celda24")
    celda.style.backgroundColor = "#dddddd"

}

function cambiar_color25() {
    celda = document.getElementById("celda25")
    celda.style.backgroundColor = "#dddddd"

}