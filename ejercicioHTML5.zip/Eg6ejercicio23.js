function agregaLista() {
    var texto = document.querySelector("#pantalla").value;
    //alert(texto);
    if (texto = "") {
        //alert("Campo texto está vacío...");
    } else {
        //alert("Campo texto está ok...");

        let lista1;
        let lista2;
        let listaUno;
        let listaDos

        ingresaUno = document.getElementById("lista1").checked;
        ingresaDos = document.getElementById("lista2").checked;
        listaUno = document.getElementById("l1");
        listaDos = document.getElementById("l2");

        let nuevaLista;

        //ingresa elemento de lista 1
        if (ingresaUno == true) {
            var texto = document.querySelector("#pantalla").value;
            nuevaLista = document.createElement("li");
            nuevaLista.innerHTML = texto;
            document.getElementById("lista1").checked = false;

            listaUno.appendChild(nuevaLista);

        } else if (ingresaDos == true) {
            var texto = document.querySelector("#pantalla").value;
            nuevaLista = document.createElement("li");
            nuevaLista.innerHTML = texto;
            document.getElementById("lista2").checked = false;

            listaDos.appendChild(nuevaLista);

        } else if (ingresaDos != true && ingresaUno != true) {

            alert("Debe marcar una opción para ingresar nuevo ítem...");
        }
    }
}