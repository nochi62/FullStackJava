$(document).ready(function() {
    $('#tabla36').DataTable();
});