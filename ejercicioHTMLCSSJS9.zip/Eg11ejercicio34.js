$(document).ready(function() {
    var i = 0;
    var arreglo = [];
    var aleatorio;

    $("#boton1").on("click", function() {
        $('.contenedor').html("-");
        i = 0;
        while (i < 20) {
            aleatorio = (Math.floor(Math.random() * 100)) + 1;
            arreglo.push(aleatorio);
            $('.contenedor').append(aleatorio + "-");
            i++;

            $('#boton2').prop('disabled', false);
            $('#boton3').prop('disabled', false);
            $('#boton4').prop('disabled', false);
            $('#boton5').prop('disabled', false);
        }
    });

    $("#boton2").on("click", function() {
        $('.contenedor').html(" - ");
        i = 0;
        while (i < 20) {
            probado = arreglo[i];
            console.log(probado);
            probadoImpar = probado % 2;

            if (probadoImpar != 0) {
                $('.contenedor').append(probado + " - ");
            } else {
                $('.contenedor').append("");
            }
            i++;
        }
    });

    $("#boton3").on("click", function() {
        $('.contenedor').html(" - ");
        i = 0;
        while (i < 20) {
            probado = arreglo[i];
            console.log(probado);
            probadoPar = probado % 2;

            if (probadoPar == 0) {
                $('.contenedor').append(probado + " - ");
            } else {
                $('.contenedor').append("");
            }
            i++;
        }
    });

    $("#boton4").on("click", function() {
        $('.contenedor').html(" - ");
        i = 0;
        while (i < 20) {
            probado = arreglo[i];
            console.log(probado);
            probadoPrimo = probado % 2;
            probadoPrimoDos = probado % 3;
            probadoPrimoTres = probado % 5;
            probadoPrimoCuatro = probado % 7;

            if ((probadoPrimo != 0) && (probadoPrimoDos != 0) &&
                (probadoPrimoTres != 0) && (probadoPrimoCuatro != 0)) {
                $('.contenedor').append(probado + " - ");
            } else {
                $('.contenedor').append("");
            }
            i++;
        }
    });

    $("#boton5").on("click", function() {
        $('.contenedor').html(" - ");
        i = 0;
        while (i < 20) {
            console.log(arreglo);
            probado = arreglo[i];
            probadoCompuesto = probado + "";

            if (probadoCompuesto.length > 1) {
                $('.contenedor').append(probado + " - ");
            } else {
                $('.contenedor').append("");
            }
            i++;
        }
    });
});