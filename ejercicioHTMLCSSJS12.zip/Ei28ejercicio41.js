$(document).ready(function() {
    // Initialize Slidebars
    var controller = new slidebars();
    controller.init();

    // Initialize Slidebars
    var controller = new slidebars();
    controller.init(function() {
        console.log('Slidebars has been initialized.');
    });

    $("#btoggle").on('click', function() {
        event.stopPropagation();
        event.preventDefault();
        controller.toggle('id-1');
    });




});

function myFunction() {
    var x = document.getElementById("mimenu");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}