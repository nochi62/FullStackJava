$(document).ready(function () {
    $("#draggable").draggable();

    $("#tabs").tabs({
        collapsible: true
    });

    $("#calidad").selectmenu();

    $("#btn").click(function () {
        alert($("#calidad").val());
    });
});
