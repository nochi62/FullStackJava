$(document).ready(function() {
    var cxt = document.getElementById("chart1").getContext('2d');
    var cities = ['Arica',
        'Iquique',
        'Calama',
        'Antofagasta',
        'Caldera',
        'La Serena',
        'Valparaíso',
        'Rodelillo',
        'Pudahue',
        'Santiago',
        'Tobalaba',
        'Juan Fernández',
        'Curicó',
        'Chillán',
        'Concepción',
        'Temuco',
        'Valdivia',
        'Osorno',
        'Puerto Montt',
        'Coyhaique',
        'Balmaceda',
        'Punta Arenas'
    ];
    var tot_fecha = [6.2,
        4.4,
        18.6,
        0.4,
        0.8,
        12.2,
        83.2,
        117.4,
        47.2,
        82,
        99.4,
        679.7,
        162.4,
        626.8,
        715.6,
        787.5,
        1052.9,
        833.8,
        1073.2,
        732.6,
        'NaN',
        311.4
    ];

    var nor_fecha = [1.6,
        0.9,
        5.9,
        2.4,
        'NaN',
        86.5,
        412.2,
        'NaN',
        275.8,
        340.6,
        365,
        1028.7,
        654.2,
        1046.4,
        1072.6,
        1117.5,
        1705.8,
        1203.8,
        1539.9,
        942.2,
        515.5,
        383.1
    ];
    var chart1 = new Chart(cxt, {
        type: 'line',

        data: {
            labels:

                cities,

            datasets: [{
                label: 'Total a la fecha',
                borderColor: 'rgb(255, 99, 132)',
                data: tot_fecha

            }, {
                label: 'Normal a la fecha',
                borderColor: 'black',
                data: nor_fecha
            }],
        },
    });
    var cxt2 = document.getElementById("chart2").getContext('2d');
    var chart1 = new Chart(cxt2, {
        type: 'bar',
        data: {
            labels: cities,
            datasets: [{
                label: 'Total a la fecha',
                backgroundColor: 'rgb(0, 99, 132)',
                borderColor: 'rgb(0, 99, 132)',
                data: tot_fecha
            }]

        },
    });

    var cxt3 = document.getElementById("chart3").getContext('2d');
    var chart3 = new Chart(cxt3, {
        type: 'pie',
        data: {
            labels: cities,
            datasets: [{
                label: 'Total a la fecha',
                backgroundColor: ['red', 'green', 'yellow', 'blue', 'NavajoWhite',
                    'Navy,',
                    'OldLace',
                    'Olive',
                    'OliveDrab',
                    'Orange',
                    'OrangeRed',
                    'Orchid',
                    'PaleGoldenRod',
                    'PaleGreen',
                    'PaleTurquoise',
                    'PaleVioletRed',
                    'PapayaWhip',
                    'PeachPuff',
                    'Peru',
                    'Pink',
                    'Plum',
                    'PowderBlue',
                ],
                data: tot_fecha
            }]

        },
    });

});