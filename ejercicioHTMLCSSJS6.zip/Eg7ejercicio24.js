var contador = 0;
var puntajeParcial = 0;
var puntajeTotal = 0;

function procesar() {

    if (contador <= 2) {
        if ((document.getElementById("rsp11").checked == true)) {

        }

        preg11 = document.getElementById("rsp11");
        preg12 = document.getElementById("rsp12");
        preg13 = document.getElementById("rsp13");
        preg21 = document.getElementById("rsp21");
        preg22 = document.getElementById("rsp22");
        preg23 = document.getElementById("rsp23");
        preg31 = document.getElementById("rsp31");
        preg32 = document.getElementById("rsp32");
        preg33 = document.getElementById("rsp33");
        preg41 = document.getElementById("rsp41");
        preg42 = document.getElementById("rsp42");
        preg43 = document.getElementById("rsp43");
        preg51 = document.getElementById("rsp51");
        preg52 = document.getElementById("rsp52");
        preg53 = document.getElementById("rsp53");

        if ((preg11.checked == true || preg12.checked == true || preg13.checked == true) &&
            (preg21.checked == true || preg22.checked == true || preg23.checked == true) &&
            (preg31.checked == true || preg32.checked == true || preg33.checked == true) &&
            (preg41.checked == true || preg42.checked == true || preg43.checked == true) &&
            (preg51.checked == true || preg52.checked == true || preg53.checked == true)) {

            if (preg11.checked == true) { puntajeParcial = ++puntajeParcial; }
            if (preg23.checked == true) { puntajeParcial = ++puntajeParcial; }
            if (preg32.checked == true) { puntajeParcial = ++puntajeParcial; }
            if (preg42.checked == true) { puntajeParcial = ++puntajeParcial; }
            if (preg51.checked == true) { puntajeParcial = ++puntajeParcial; }

            puntajeTotal = puntajeParcial;

            contador = ++contador;
            alert("Oportunidad " + contador + ": " + puntajeParcial + " puntos");

            if (puntajeParcial == 5) {
                document.getElementById('boton').disabled = true;
                alert('Respondió correctamente todas las preguntas, tu puntaje fue de ' + puntajeParcial + ' puntos.');
            } else {
                if (contador == 3) {
                    alert('terminaron sus oportunidades ...siga participando ' + puntajeParcial + ' puntos.');
                    document.getElementById('boton').disabled = true;
                }
            }

            puntajeParcial = 0;

        } else {
            alert(rsp11);
            alert("Debe marcar un alternativa en todas las preguntas...");
        }
    } else {
        alert("Excedió sus oportunidades...");
    }
}