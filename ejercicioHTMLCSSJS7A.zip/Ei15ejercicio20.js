function actualizarpag() {
    mostrarFecha();
    location.reload(true);
}

var mifecha = new Date();

function cuentaRegresiva() {
    const findeano = "December 31 2020 23:59:59";
    var total = Date.parse(findeano) - Date.parse(new Date());
    //document.querySelector("#regresiva").innerHTML = total;
    const seconds = Math.floor((total / 1000) % 60);
    const minutes = Math.floor((total / 1000 / 60) % 60);
    const hours = Math.floor((total / (1000 * 60 * 60)) % 24);
    const days = Math.floor(total / (1000 * 60 * 60 * 24));
    return {
        total,
        days,
        hours,
        minutes,
        seconds
    }
}

function mostrarFecha() {

    var dia = parseInt(mifecha.getDate());

    var dialetra = " ";
    switch (dia) {
        case 1:
            {
                dialetra = "Lunes";
                break;
            }
        case 2:
            {
                dialetra = "Martes";
                break;
            }
        case 3:
            {
                dialetra = "Miércoles";
                break;
            }
        case 4:
            {
                dialetra = "Jueves";
                break;
            }
        case 5:
            {
                dialetra = "Viernes";
                break;
            }
        case 6:
            {
                dialetra = "Sábado";
                break;
            }
        case 7:
            {
                dialetra = "Domingo";
                break;
            }
        default:
            {
                dialetra = dia;
                break;
            }

    }


    var diames = (parseInt(mifecha.getMonth()) + 1);

    switch (diames) {
        case 0:
            {
                mesletra = "Enero";
                break;
            }
        case 1:
            {
                mesletra = "Febrero";
                break;
            }
        case 2:
            {
                mesletra = "Marzo";
                break;
            }
        case 3:
            {
                mesletra = "Abril";
                break;
            }
        case 4:
            {
                mesletra = "Mayo";
                break;
            }
        case 5:
            {
                mesletra = "Junio";
                break;
            }
        case 6:
            {
                mesletra = "Julio";
                break;
            }
        case 7:
            {
                mesletra = "Agosto";
                break;
            }
        case 8:
            {
                mesletra = "Septiembre";
                break;
            }
        case 9:
            {
                mesletra = "Octubre";
                break;
            }
        case 10:
            {
                mesletra = "Noviembre";
                break;
            }
        case 11:
            {
                mesletra = "Diciembre";
                break;
            }
        default:
            {
                mesletra = dia;
                break;
            }
    }



    var ano = mifecha.getFullYear();

    //var dia = mifecha.getDay();

    //var mes = (mifecha.getMonth() + 1);
    var hora = mifecha.getHours();
    var minutos = mifecha.getMinutes();
    var segundos = mifecha.getSeconds();

    var fechatoda = "hoy es " + dialetra + " " + dia + " de " + mesletra + " de " + ano + " y son las " + hora + " horas " + minutos + " minutos con " + segundos + " segundos";
    document.querySelector("#tiempo").innerHTML = fechatoda;

    var countdownstring = "Faltan " + cuentaRegresiva().days + " dias, " + cuentaRegresiva().hours + " horas, " + cuentaRegresiva().minutes +
        " minutos y " + cuentaRegresiva().seconds + " segundos, para fin de año..."
    document.querySelector("#regresiva").innerHTML = countdownstring;
}