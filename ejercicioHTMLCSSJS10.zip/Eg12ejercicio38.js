$(function() {

    $("#boton").on("click", function() {
        alert("entro");
        $("#form1").validate({

            rules: {
                nombre: { required: true, nombre: true, minlength: 8, maxlength: 30 }
            },
            messages: {
                nombre: { required: 'El campo es requerido', minlength: 'Mínimo 8 caracteres', maxlength: 'máximo 30 caracteres' }
            }
        });
    });
});


/*
$(document).ready(function() {
    $('#tabla36').DataTable();
});*/