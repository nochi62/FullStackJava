    var param = 0;

    function playPhotosAnt() {
        var list_photos = ["images/Helena.jpg", "images/cook.jpg", "images/jennifer.jpg", "images/rubberduck.jpg",
            "images/Ali.jpg"
        ];

        if (param == 0) {
            param = 4;
        } else if (param == 4) {
            param = 3;
        } else {
            param = param - 1;
        }

        document.getElementById("mypict").src = (list_photos[param]);

        document.getElementById("p1").innerHTML = (list_photos[param]);
    }

    function playPhotoSig() {
        var list_photos = ["images/Helena.jpg", "images/cook.jpg", "images/jennifer.jpg", "images/rubberduck.jpg",
            "images/Ali.jpg"
        ];

        if (param == -1) {
            param = 4;
        } else if (param == 4) {
            param = 0;
        } else {
            param = param + 1;
        }

        document.getElementById("mypict").src = (list_photos[param]);

        document.getElementById("p1").innerHTML = (list_photos[param]);
    }

    function playPhotosRnd() {
        var list_photos = ["images/Helena.jpg", "images/cook.jpg", "images/jennifer.jpg", "images/rubberduck.jpg",
            "images/Ali.jpg"
        ];

        var rand = 0;
        rand = Math.floor((Math.random() * 5) + 1);
        rand = (rand - 1);

        param = rand;

        document.getElementById("mypict").src = (list_photos[param]);
        //console.log(list_photos[param]);
        document.getElementById("p1").innerHTML = (list_photos[param]);
    }