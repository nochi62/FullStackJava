$(document).ready(function() {
    $("#form1").validate();

    $(".submit").click(function() {

        var a = $("#nombre").val();
        var e = $("#apellido").val();
        var i = $("#email").val();
        var o = $("#edad").val();
        var u = $("#telefono").val();

        $("#tabla1").append("<tr><td>" + a + "</td><td>" + e + "</td><td>" + i + "</td><td>" + o + "</td><td>" + u + "</td></tr>");

        $("#form1")[0].reset();

    });

    $("#tabla1").tableExport({

        headings: true, // (Boolean), display table headings (th/td elements) in the <thead>
        footers: true, // (Boolean), display table footers (th/td elements) in the <tfoot>
        formats: ["xls", "csv", "txt"], // (String[]), filetypes for the export
        fileName: "id", // (id, String), filename for the downloaded file
        bootstrap: false, // (Boolean), style buttons using bootstrap
        position: "bottom", // (top, bottom), position of the caption element relative to table
        ignoreRows: null, // (Number, Number[]), row indices to exclude from the exported file(s)
        ignoreCols: null, // (Number, Number[]), column indices to exclude from the exported file(s)
        ignoreCSS: ".tableexport-ignore", // (selector, selector[]), selector(s) to exclude from the exported file(s)
        emptyCSS: ".tableexport-empty", // (selector, selector[]), selector(s) to replace cells with an empty string in the exported file(s)
        trimWhitespace: false
    });

});